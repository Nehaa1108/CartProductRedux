
import './App.css';
import Clock from './component/Clock';


function App() {


  return (
    <div className="App">
    
    <Clock/>
    </div>
  );
}

export default App;

